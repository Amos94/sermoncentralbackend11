import SermonCentralDatabase
from SermonCentralDataMining import SermonCentralDataMining



class SermonCentralDatabaseFiller():

    def __init__(self,lastSermonId):
        db = SermonCentralDatabase.Queries()
        db.dbConnection()

        # sdms = []
        # sdms_objects = []
        #
        # for i in range(1, 20):
        #     sdms.append(SermonCentralDataMining.SermonCentralDataMining(i))
        #     sdms_objects.append(sdms[i-1].createContent())
        # print sdms_objects[5][100]

        for i in range(62743, lastSermonId):
            try:
                sdm = SermonCentralDataMining(i)
                array = sdm.createContent()
                print array
                print "Try to add sermon: "+str(i)+".html"

                if(str(array[0]) != 'Page Not Found - SermonCentral.com'):
                    #add to database
                    toReturn = db.insertNewSermon(str(array[0]), str(array[1]), str(array[2]))
                    #make copy on disk
                    # new_file = open("C:\\Users\\Amos\\Desktop\\new sermons\\"+str(array[0])+".html","w+")
                    # new_file.write(str[array[1]])
                    # new_file.close()
                    if(toReturn == 'OK'):
                        print "Added sermon with name: " + str(i) + ".html"
                    else:
                        print "Problem with adding to the database"
                else:
                    print "Don't add because it's a 404 error"
            except:
                print "Unexpected error"
                raise
            del sdm

        return toReturn


        # for i in range(1, lastSermonId):
        #     try:
        #         sdm = SermonCentralDataMining.SermonCentralDataMining(i)
        #         array = sdm.createContent()
        #         print array
        #         print "Try to add sermon: "+str(i)+".html"
        #         if(array[0] != 'Page Not Found - SermonCentral.com'):
        #             connection.insertNewSermon(array[0], array[1], array[2])
        #             print "Added sermon with name: "+str(i)+".html"
        #     except:
        #         print "Unexpected error"
        #         raise


scdf = SermonCentralDatabaseFiller(209882)

#left at 62743


# class C():
#     def __init__(self,i):
#         print "I am %s" % (str(i))
#
# for i in range (0,10):
#     c = C(i)
#     print c