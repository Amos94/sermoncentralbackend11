from bs4 import BeautifulSoup
import urllib


for i in range(209881, 209882):
    r = urllib.urlopen('https://www.sermoncentral.com/Sermons/Print?sermonId='+str(i)).read()

    target = open("C:\\Users\\Amos\\Desktop\\sermon\\"+str(i)+".html", 'w')

    target.write(r)

#ULTIMA PREDICA: 209881