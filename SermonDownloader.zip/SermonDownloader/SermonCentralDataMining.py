import bs4
import re


class SermonCentralDataMining():

    file = None
    html = ""
    titleAndContent = []
    title_on_disk = ""

    def __del__(self):
        self.file = None
        self.html = ""
        self.titleAndContent = []
        self.title_on_disk = ""
        print "deleted"

    def __init__(self, id):
        self.title_on_disk = str(id)+".html"
        path = "C:\\Users\\Amos\\Desktop\\sermon\\"+str(id)+".html"
        self.file = open(path,"r")
        self.titleAndContent = []
        print "I am %s" %(str(id))

    def createContent(self):

        soup = bs4.BeautifulSoup(self.file.read())
        title = soup.findAll('title')
        sub_title = soup.findAll('h2')
        content = soup.findAll("p")
        raw_title = ""

        self.html = "<html><head>"

        for r in title:
            self.html += str(r) + ""
            raw_title = str(r)

        self.html += "</head><body><div class=\"content\">"
        cleanr = re.compile('<.*?>')
        self.html += "<h1>Title: "+re.sub(cleanr, '', raw_title) + "</h1>"
        self.titleAndContent.append(re.sub(cleanr, '', raw_title))


        for s in sub_title:
            self.html += str(s)

        for p in content:
            self.html +=str(p)

        self.html += "</div></body></html>"

        self.titleAndContent.append(self.html)
        self.titleAndContent.append(self.title_on_disk)
        self.file.close()

        return self.titleAndContent
