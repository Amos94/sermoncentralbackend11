import MySQLdb
import json

class Queries():
    #creating the database object
    db = None

    def dbConnection(self):
        # Open database connection
        self.db = MySQLdb.connect("localhost","root","Amos.expert94","sermoncentral" )


    #insertion of new sermon
    def insertNewSermon(self, title, content,title_on_disk):
        # prepare a cursor object using cursor() method
        cursor = self.db.cursor()
        title = json.dumps(title)
        content = json.dumps(content)
        title_on_disk = json.dumps(title_on_disk)
        #print title
        #print content
        #print title_on_disk
        #preparing the SQL command for execution => title = SERMON TITLE; contant = SERMON CONTENT;
        sql = "INSERT INTO sermons(title, content, name_on_disk) VALUES('"+str(title)+"', '"+str(content)+"' , '"+str(title_on_disk)+"')"

        toReturn = "NOT OK"
        print "try to insert row"
        try:
            # execute SQL query using execute() method.
            cursor.execute(sql)
            self.db.commit()
            print("row inserted")
            toReturn = "OK"
        except Exception, e:
            print("row not inserted for the reason " + str(e))
            #self.db.rollback()
        #self.db.close()
        return toReturn



    #get all the sermons
    def getSermons(self):
        # prepare a cursor object using cursor() method
        cursor = self.db.cursor()

        #preparing the SQL command for execution => title = SERMON TITLE; contant = SERMON CONTENT;
        sql = "SELECT * FROM sermons"

        # execute SQL query using execute() method.
        cursor.execute(sql)
        result = cursor.fetchall()

        self.db.close()

        return result




    #get sermon by id
    def getSermons(self, id):
        # prepare a cursor object using cursor() method
        cursor = self.db.cursor()

        #preparing the SQL command for execution => title = SERMON TITLE; contant = SERMON CONTENT;
        sql = "SELECT * FROM sermons WHERE id=%s" % (id)

        # execute SQL query using execute() method.
        cursor.execute(sql)
        result = cursor.fetchone()
        self.db.close()

        return result